<?php
	$conn = new PDO( 'mysql:host=localhost;dbname=db_pdo_search', 'root', '');
	if(!$conn){
		die("Erro: Sem ligação à base de dados!");
	}
?>
