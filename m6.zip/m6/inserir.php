<?php
	require_once 'conn.php';
 
	if(ISSET($_POST['guardar'])){
 
		$nome = $_POST['nome'];
		$apelido = $_POST['apelido'];
		$morada = $_POST['morada'];
		
 
 
		try{
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO `utilizadores`(nome, apelido, morada)  VALUES ('$nome', '$apelido', '$morada')";
			$conn->exec($sql);
		}catch(PDOException $e){
			echo $e->getMessage();
		}
 
		$conn = null;
 
		header("location: index.php");
 
	}
?>
