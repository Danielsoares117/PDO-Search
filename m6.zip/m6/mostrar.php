<?php
    require_once 'conn.php';
 
    if(ISSET($_POST['id'])){
        $sql = "SELECT * FROM 'utilizadores'";
        $query = $conn->prepare($sql);
        $query->execute();
 
        while($fetch = $query->fetch()){
?>
 
<tr>
    <td><?php echo $fetch['nome']?></td>
    <td><?php echo $fetch['apelido']?></td>
    <td><?php echo $fetch['morada']?></td>
</tr>
 
<?php
        }
    }
?>